package Model.Exceptions;

import javax.swing.JOptionPane;

public class IncompleteInputException extends Exception{
	public IncompleteInputException(String message) {
		super(message);

    }
}
